'''
This is your module which has the code that is general enough
to be used by other people.
'''

def hello_world(name=None):
    print(f"Hello {name}!")